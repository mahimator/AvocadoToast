---
name: Lumina Ambient Audio
colors:
  surface: '#101319'
  surface-dim: '#101319'
  surface-bright: '#36393f'
  surface-container-lowest: '#0b0e13'
  surface-container-low: '#191c21'
  surface-container: '#1d2025'
  surface-container-high: '#272a30'
  surface-container-highest: '#32353b'
  on-surface: '#e1e2ea'
  on-surface-variant: '#c0c8cb'
  inverse-surface: '#e1e2ea'
  inverse-on-surface: '#2d3036'
  outline: '#8a9295'
  outline-variant: '#40484b'
  surface-tint: '#9dcede'
  primary: '#b4e5f6'
  on-primary: '#003641'
  primary-container: '#98c9d9'
  on-primary-container: '#225563'
  inverse-primary: '#346573'
  secondary: '#c5c2ee'
  on-secondary: '#2e2d4f'
  secondary-container: '#47456a'
  on-secondary-container: '#b7b4df'
  tertiary: '#d9dee3'
  on-tertiary: '#2c3135'
  tertiary-container: '#bdc2c7'
  on-tertiary-container: '#4a5054'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b9eafb'
  primary-fixed-dim: '#9dcede'
  on-primary-fixed: '#001f27'
  on-primary-fixed-variant: '#184d5a'
  secondary-fixed: '#e3dfff'
  secondary-fixed-dim: '#c5c2ee'
  on-secondary-fixed: '#191739'
  on-secondary-fixed-variant: '#444367'
  tertiary-fixed: '#dee3e8'
  tertiary-fixed-dim: '#c2c7cc'
  on-tertiary-fixed: '#171c20'
  on-tertiary-fixed-variant: '#42474c'
  background: '#101319'
  on-background: '#e1e2ea'
  surface-variant: '#32353b'
typography:
  display:
    fontFamily: Plus Jakarta Sans
    fontSize: 40px
    fontWeight: '300'
    lineHeight: 48px
    letterSpacing: -0.03em
  display-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '300'
    lineHeight: 38px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.04em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '600'
    lineHeight: 12px
    letterSpacing: 0.06em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin: 1.25rem
  margin-tablet: 2rem
  margin-desktop: 3.5rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style
The design system embodies quiet luxury, acoustic serenity, and contemplative focus for high-fidelity personal listening. It rejects aggressive neon indicators, saturated gradients, and visual noise in favor of ethereal translucency, deep spatial depth, and acoustic calm. The interface recedes entirely, allowing artwork, soundscapes, and typography to breathe within an expansive, low-light architectural space.

The style fuses **Liquid Minimalist Glassmorphism** with Apple-inspired restraint:
- Deep optical blurs evoking cold frosted crystal and fluid glass lenses.
- Ethereal, low-luminance lighting accents derived from soft moonlit refractions rather than synthetic LEDs.
- Generous, meditative negative space structured around a strict spatial hierarchy where every interaction feels deliberate, weightless, and calm.

## Colors
The palette is rooted in an abyss of deep slate and velvet obsidian, animated only by moonlight refractions and soft atmospheric twilight. Accents are applied as subtle luminescent glimmers and diffused aura pools rather than solid opaque fills.

- **Primary (`#98C9D9` - Moonlight Cyan):** Atmospheric spectral blue used for active playback states, fluid scrubbers, and focused tracks.
- **Secondary (`#B8B5E0` - Whispering Lavender):** Muted chromatic mist for secondary states, spatial audio toggles, and delicate badges.
- **Tertiary (`#E8EDF2` - Opal Mist):** Pure specular sheen used for high-emphasis typography, pristine icon highlights, and reflective edges.
- **Neutral (`#080B10` - Deep Void):** Sub-zero black with a hint of deep oceanic navy, serving as the canvas backdrop that allows translucent frosted layers to float with profound spatial separation.

### Functional Tinting & Alpha Hierarchy
- Glass Base Fill: `rgba(18, 24, 34, 0.45)`
- Glass Surface Elevated: `rgba(28, 36, 50, 0.55)`
- Specular Stroke (Top/Left): `rgba(255, 255, 255, 0.12)`
- Specular Stroke (Bottom/Right): `rgba(255, 255, 255, 0.03)`
- Text Low-Contrast/Muted: `rgba(232, 237, 242, 0.42)`

## Typography
Plus Jakarta Sans provides crisp modern geometry tempered by subtle organic curves, mirroring Apple's San Francisco in structural purity while contributing a softer, warmer ambient signature. 

- **Weights:** Heavily emphasizes `300 Light` and `400 Regular` for track titles and artist names to preserve an airy, quiet elegance. `500 Medium` and `600 SemiBold` are reserved exclusively for critical metadata, tiny timestamps, and navigational labels.
- **Tracking:** Negative tracking on large titles compresses letterforms into refined optical blocks; expanded letter-spacing on labels (`label-md`, `label-sm`) provides clarity at micro-scales against translucent surfaces.
- **Hierarchy Rules:** Metadata (e.g., bit-depth, codec tags, album year) must always render in subdued opacity (`rgba(232, 237, 242, 0.42)`) using `label-md` to avoid competing with album artistry and core playback controls.

## Layout & Spacing
The layout model employs a fluid, edge-to-edge canvas with expansive architectural breathing room, preventing the claustrophobic density typical of complex audio applications.

- **Grid Architecture:** 
  - **Mobile:** 4-column fluid layout with dynamic bottom safe-area offsets for floating glass navigation docks.
  - **Tablet:** 8-column layout allowing parallel viewing of contextual queue management alongside expansive album visuals.
  - **Desktop / Large Displays:** 12-column fixed-max layout (max content container width `1280px`), flanked by ambient negative margins that catch background light refractions.
- **Rhythm & Safe Insets:** Component internal spacing adheres strictly to 8pt increments with 4pt half-steps (`space-xs`). Floating elements maintain a minimum clearance of `space-xl` from viewport edges to ensure an uninterrupted sense of suspension.

## Elevation & Depth
Elevation is rendered entirely without heavy, murky drop-shadows. Depth is established through optical refractions, layered variable blurs, and directional rim lighting.

1. **Backdrop Blurs:**
   - Level 0 (Base Canvas): Raw deep space (`#080B10`), unfiltered.
   - Level 1 (Sheets & Recessed Trays): `backdrop-filter: blur(20px)`, tinted with `rgba(14, 18, 26, 0.6)`.
   - Level 2 (Floating Glass Panels & Cards): `backdrop-filter: blur(28px)`, filled with `rgba(20, 26, 38, 0.45)`.
   - Level 3 (Active Modals & Scrub Bar Floats): `backdrop-filter: blur(36px) saturate(140%)`, filled with `rgba(28, 36, 52, 0.6)`.

2. **Specular Rim Lighting & Inners:**
   - Each floating glass container receives a compound rim border: a 1px perimeter border rendered via a linear gradient from top-left (`rgba(255, 255, 255, 0.14)`) fading downward to bottom-right (`rgba(255, 255, 255, 0.02)`).
   - An interior top inset highlight (`box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.1)`) mimics the physical bevel of polished crystal glass catching top-down studio ambient lighting.

3. **Ambient Halo / Luminescent Glow:**
   - When interactive playback is active, an ultra-diffused atmospheric glow shines from behind the primary artwork or play control: `box-shadow: 0 16px 48px -12px rgba(152, 201, 217, 0.16)`.

## Shapes
Geometry emphasizes smooth, continuous curvature (squircle / continuous corners) reminiscent of Apple industrial design. Sharp angles and abrupt hard edges are forbidden.

- **Base Radius (0.5rem / 8px):** Subtle interactive controls, volume track caps, and contextual dropdown selectors.
- **Large Radius (1rem / 16px):** Album artwork thumbnails, queue row highlights, and ambient information cards.
- **Extra Large Radius (1.5rem / 24px):** Floating player bottom sheet, persistent docked glass bars, and modal dialogue overlays.
- **Continuous Pill Form:** Applied unconditionally to buttons, search pills, timeline scrubber handles, and active audio tag chips.

## Components

### Buttons & Interactive Controls
- **Primary Playback Controls:** 
  - Play/Pause button: 64x64px circular glass lens with `backdrop-filter: blur(32px)`, surface fill `rgba(152, 201, 217, 0.12)`, 1px border `rgba(152, 201, 217, 0.25)`, and an ambient back-glow in Moonlight Cyan. On press, scales to `0.96` with an increase in inner white specular opacity.
  - Secondary Transport (Skip/Shuffle): Ghost icons using `tertiary_color_hex` at 70% opacity, transitioning to 100% on hover/touch without background containers.
- **Action Pills:** Full pill-shaped containers with 12px horizontal padding, 6px vertical padding, subtle `1px border-white/10`, and text set to `label-md`.

### Audio Progress & Fluid Scrubbers
- **Track Line:** 3px thick rounded track with background `rgba(255, 255, 255, 0.08)`.
- **Played Fill:** Smooth gradient from Moonlight Cyan (`#98C9D9`) to Whispering Lavender (`#B8B5E0`) with a faint ambient bloom along its length.
- **Thumb Indicator:** 14px circle with an inner white core, surrounded by an 8px frosted glass ring halo that expands fluidly to 20px upon user touch or drag.

### Frosted Cards & Art Surfaces
- **Album / Artist Cards:** Translucent pane with `backdrop-filter: blur(28px)`, filled with `rgba(18, 24, 34, 0.45)`. Artwork features a delicate 0.5px inner white stroke to isolate deep dark album covers from the dark frosted container.
- **Hover/Active State:** Soft surface lightening to `rgba(25, 33, 46, 0.65)` with a +2px Y translation and an ethereal soft shadow expansion.

### Lists & Track Rows
- **List Items:** Row height minimum of 56px with generous horizontal insets. Separator lines are omitted entirely; hierarchy is maintained solely through consistent vertical spacing and subtle hover/active surface highlight fills (`rgba(255, 255, 255, 0.04)`).
- **Active Track Row:** Preceded by an animated 3-bar miniature visualizer pulse in `#98C9D9`; song title transitions to `#98C9D9` in `headline-sm`.

### Input Fields & Search
- **Search Bar:** Pill-shaped glass container, 44px height, filled with `rgba(255, 255, 255, 0.05)`, featuring an inset shadow (`inset 0 1px 2px rgba(0, 0, 0, 0.25)`). Left-aligned magnifying icon at 40% opacity; text entry renders in `body-md` with white specular shine.

### Chips & Badges (Hi-Res Audio, Spatial Sound)
- **Audio Attribute Badges:** 20px height, 8px horizontal padding, border radius 4px. Ultra-fine 1px border (`rgba(255, 255, 255, 0.15)`), transparent fill, typography set to `label-sm` in all-caps with `+0.08em` tracking.