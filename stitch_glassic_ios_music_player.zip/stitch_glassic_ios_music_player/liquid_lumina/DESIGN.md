---
name: Liquid Lumina
colors:
  surface: '#131317'
  surface-dim: '#131317'
  surface-bright: '#39393e'
  surface-container-lowest: '#0e0e12'
  surface-container-low: '#1b1b20'
  surface-container: '#1f1f24'
  surface-container-high: '#2a292e'
  surface-container-highest: '#353439'
  on-surface: '#e4e1e8'
  on-surface-variant: '#b9cacb'
  inverse-surface: '#e4e1e8'
  inverse-on-surface: '#303035'
  outline: '#849495'
  outline-variant: '#3a494b'
  surface-tint: '#00dce6'
  primary: '#e0fdff'
  on-primary: '#00373a'
  primary-container: '#00f2fe'
  on-primary-container: '#006a70'
  inverse-primary: '#00696f'
  secondary: '#ffb3b3'
  on-secondary: '#680015'
  secondary-container: '#ff5261'
  on-secondary-container: '#5b0012'
  tertiary: '#fef4ff'
  on-tertiary: '#470083'
  tertiary-container: '#e9d2ff'
  on-tertiary-container: '#8132d2'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#6ff6ff'
  primary-fixed-dim: '#00dce6'
  on-primary-fixed: '#002022'
  on-primary-fixed-variant: '#004f53'
  secondary-fixed: '#ffdad9'
  secondary-fixed-dim: '#ffb3b3'
  on-secondary-fixed: '#40000a'
  on-secondary-fixed-variant: '#920022'
  tertiary-fixed: '#efdbff'
  tertiary-fixed-dim: '#dbb8ff'
  on-tertiary-fixed: '#2b0052'
  on-tertiary-fixed-variant: '#6600b7'
  background: '#131317'
  on-background: '#e4e1e8'
  surface-variant: '#353439'
typography:
  display-hero:
    fontFamily: Plus Jakarta Sans
    fontSize: 48px
    fontWeight: '800'
    lineHeight: 52px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 36px
    fontWeight: '800'
    lineHeight: 40px
    letterSpacing: -0.025em
  headline-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 38px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Plus Jakarta Sans
    fontSize: 26px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: -0.015em
  headline-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: -0.01em
  body-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0em
  body-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
    letterSpacing: 0.01em
  label-caps:
    fontFamily: Inter
    fontSize: 11px
    fontWeight: '600'
    lineHeight: 14px
    letterSpacing: 0.06em
  tech-badge:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.04em
  timestamp:
    fontFamily: JetBrains Mono
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 14px
    letterSpacing: -0.01em
rounded:
  sm: 0.5rem
  DEFAULT: 1rem
  md: 1.5rem
  lg: 2rem
  xl: 3rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-mobile: 0.75rem
  margin: 2rem
  margin-mobile: 1rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2.5rem
---

## Brand & Style

This design system defines an immersive, tactile, and sensory-driven audio streaming interface. It fuses the optical depth of iOS liquid glass—refractive surfaces, specular highlights, and chromatic backdrops—with dynamic algorithmic exploration models.

### Design Movement: Fluid Glassmorphism & High-Contrast Dark
- **Tactile Optics:** Layers simulate physical acrylic with micro-beveled borders (`1px` translucent strokes) and deep background diffusion (`backdrop-blur-2xl`).
- **Sonic Immersion:** The interface acts as an ambient canvas; dynamic album art bleeds into navigation bars, player sheets, and cards via localized color projection.
- **Precision Utility:** Utilitarian audio controls, dynamic frequency waveforms, and cryptographic-style fidelity badges contrast against soft organic glows.

## Colors

The color architecture is calibrated exclusively for deep OLED displays, providing infinite dynamic range and power efficiency.

### System Palette
- **Canvas Base (`#08080C`):** Absolute deep obsidian, grounding the viewport and eliminating light bleed.
- **Surface Elevation (`#12121A`):** Low-luminance slate for secondary canvases and modular grouping.
- **Electric Cyan (`#00F2FE`):** Primary interactive element, dynamic playback scrubber, and live stream indicators.
- **Neon Coral (`#FF0844`):** Secondary accent for favorites, curated recommendations, and live radio broadcasting tags.
- **Prismatic Violet (`#7928CA`):** Tertiary depth layer used in radial mesh gradients, Dolby spatial badges, and mix transitions.

### Surface Transmission Tokens
- **Ultra-Thin Glass:** `rgba(255, 255, 255, 0.04)` over `backdrop-filter: blur(20px) saturate(190%)`
- **Interactive Glass:** `rgba(255, 255, 255, 0.08)` over `backdrop-filter: blur(40px) saturate(210%)`
- **Elevated Glass:** `rgba(255, 255, 255, 0.12)` over `backdrop-filter: blur(60px) saturate(240%)`
- **Border Specular Accent:** `rgba(255, 255, 255, 0.12)` top/left gradient trailing to `rgba(255, 255, 255, 0.02)` bottom/right.

## Typography

The typography couples the human-centric geometric clarity of Plus Jakarta Sans for editorial presence with Inter's neutral micro-legibility for dynamic track listings and discovery streams. JetBrains Mono is assigned strictly to audio telemetry, technical badges, audio sample rates, and scrubbing timestamps to invoke precision equipment aesthetics.

- **Editorial Hierarchy:** Display sizes apply tight negative tracking to emulate high-end print titles while anchoring cover art.
- **Metadata Separation:** Track titles use `body-md` (Medium weight), whereas artist and release attributions step down to secondary opacity (`#FFFFFF` at 64% alpha) using `body-sm`.
- **Audio Telemetry:** All bitrate figures, elapsed playback times, and format declarations must be tabular-figured to prevent layout shift during active playback.

## Layout & Spacing

The layout runs on a responsive 4-column (mobile) to 12-column (tablet/desktop) fluid grid system anchored by fixed top and bottom system overlays.

### Spatial Flow
- **Floating Overlays:** The bottom navigation bar and mini-player float above content layers with an inset of `space-md` from the screen perimeter.
- **Scroll Padding:** Content containers declare bottom scroll clearance equivalent to the mini-player height + navigation bar height + `space-xl` (`148px` aggregate mobile clearance).
- **Horizontal Discovery Carousels:** algorithmic trays snap horizontally (`scroll-snap-type: x mandatory`) with an offset margin equal to `margin-mobile` to sustain page edge bleeding.

## Elevation & Depth

Visual hierarchy uses physical optical layering (Z-index stacking combined with real-time hardware blur) rather than traditional drop shadows.

### Surface Tiers
- **Tier 0 (Root Canvas):** `#08080C` with an optional radial gradient layer reflecting active artwork palette blurs (`blur(120px)`, 15% opacity).
- **Tier 1 (Cards & Rows):** Translucent acrylic (`rgba(255, 255, 255, 0.04)`), 1px solid stroke of `rgba(255, 255, 255, 0.06)`. No box shadow.
- **Tier 2 (Floating Floating Shells & Sheets):** Mini-player and bottom navigation dock. `rgba(18, 18, 26, 0.72)` with `backdrop-filter: blur(40px) saturate(200%)`. Border: 1px `rgba(255, 255, 255, 0.12)`. Subtle directional inner glow: `inset 0 1px 0 0 rgba(255, 255, 255, 0.15)`.
- **Tier 3 (Modals & Full-Screen Player):** Dynamic canvas using the current playing track's vibrant colors dispersed across a 3-point animated mesh gradient, darkened by an overarching 40% black glass veneer.

## Shapes

The design system uses a pill-dominant, fluid contour language referencing consumer electronics hardware and contemporary iOS design patterns.

- **Pill Primitives:** Buttons, filter chips, audio badges, and the floating player dock utilize complete continuous curvature (`roundedness: 3` / pill shape).
- **Media Containers:** Album artwork, playlist covers, and dynamic video canvases employ `rounded-xl` (`2rem` / `32px` on desktop, scaled to `1.5rem` / `24px` on mobile) to balance structural weight against pills.
- **Micro UI Elements:** Checkboxes, sliders, and audio progress tracks use rounded terminal caps.

## Components

### Floating Glass Mini-Player
- **Geometry:** Height: `64px`, full width minus dual `space-md` outer margins, pill-shaped (`rounded-full`).
- **Surface:** `rgba(18, 18, 26, 0.65)` layered with `backdrop-blur-2xl` and a `1px` border of `rgba(255, 255, 255, 0.1)`.
- **Internal Elements:** 
  - Left: `48px` circular spinning vinyl thumbnail or rounded album art (`rounded-md`).
  - Center: Scrolling marquee track title (`body-md` SemiBold) stacked above artist name (`body-sm` at 60% white).
  - Right: Play/Pause tactile pill, Next Track icon, and contextual audio output route icon (AirPlay/Bluetooth).
  - Track Progress: Micro-height (`2px`) scrubber line running strictly along the bottom perimeter contour.

### Interactive Buttons & Dynamic Pills
- **Primary Action (Play/Shuffle):** Solid white (`#FFFFFF`) with contrasting absolute black text (`#08080C`). On press: scales to `0.96` with `80ms` spring physics.
- **Glass Action (Secondary):** Surface of `rgba(255, 255, 255, 0.08)`, text `#FFFFFF`, border `1px rgba(255, 255, 255, 0.12)`.
- **Active Filter Chips (Algorithmic Categories):** Pill shape. Inactive: `rgba(255, 255, 255, 0.05)`. Active: Gradient fill (`#00F2FE` to `#7928CA`) with white text and a diffuse glow: `0 0 16px rgba(0, 242, 254, 0.3)`.

### Technical Audio Badges
- **Lossless / Hi-Res / Dolby Atmos:** Container height `18px`, padding `0 6px`, border radius `4px`.
- **Surface:** `rgba(255, 255, 255, 0.06)`, border `0.5px solid rgba(255, 255, 255, 0.15)`.
- **Text:** `tech-badge` token, uppercase, rendered in `#FFFFFF` with 80% opacity.

### Audio Scrubber & Visualizers
- **Scrubber Track:** Unplayed segment `rgba(255, 255, 255, 0.12)`, played segment vibrant gradient from `#00F2FE` to `#FF0844`. Thumb indicator is an elevated glass bead (`14px` circle) with a center core of pure white and a `0 2px 8px rgba(0,0,0,0.5)` drop shadow.
- **Dynamic EQ Visualizer:** 4 to 12 vertical bars (`width: 3px`, `gap: 2px`) animated via web audio API / AVFoundation frequency arrays, utilizing Neon Coral to Electric Cyan vertical linear fills.

### Cards & Media Cells
- **Discovery Card:** Vertically stacked. Top asset: square `1:1` cover artwork featuring a micro-inset outline (`inset 0 0 0 1px rgba(255,255,255,0.08)`).
- **Algorithmic Mix Card:** Embedded animated canvas preview behind ultra-thin frosted glass panel displaying personalized mix tags, track counts, and waveform previews.